Make a demo.docx file in the folder with these files.

install packages, then:
python First.py
python Sec.py
Make a Imag folder and move all images.
python Third.py